# SYU AUTO — 2.11 Mobile + SEO

Добавено:
- responsive/mobile CSS
- Bulgarian HTML language
- SEO title/description/keywords
- Open Graph metadata
- robots.txt чрез Next.js
- sitemap.xml чрез Next.js
- mobile-friendly form controls

Следва:
1. Production security review (Admin/RLS)
2. Real domain + Vercel deployment
3. Supabase production setup
4. Stripe live mode
5. Final testing on phone
