# SYU AUTO — Launch Checklist

- [ ] Domain selected and registered
- [ ] Vercel project connected
- [ ] Production Supabase project configured
- [ ] RLS verified
- [ ] Admin authorization verified server-side
- [ ] Storage upload rules verified
- [ ] Stripe test payment verified
- [ ] Stripe production webhook verified
- [ ] Mobile testing completed
- [ ] Privacy Policy / Terms added
- [ ] Backup plan configured
- [ ] Final smoke test completed
